# Loading checks

All 16 routes and their referenced CSS, JavaScript, images and fonts returned HTTP 200. Unknown routes returned the custom space-themed 404 with status 404.

| Page | HTML KB | All referenced assets KB | Assets | Local HTML response ms |
|---|---:|---:|---:|---:|
| /404 | 11.5 | 155.6 | 8 | 126.3 |
| /about | 16.3 | 133.9 | 7 | 8.3 |
| /acceptable-use | 14.6 | 133.9 | 7 | 6.2 |
| /ai-assistant | 19.6 | 133.9 | 7 | 6 |
| /contact | 17 | 133.9 | 7 | 4.1 |
| /cookies | 15.4 | 133.9 | 7 | 3.9 |
| /faq | 36.3 | 133.9 | 7 | 4.8 |
| /features | 36 | 133.9 | 7 | 4.4 |
| /how-it-works | 20.4 | 133.9 | 7 | 4.4 |
| / | 100.9 | 135.5 | 8 | 26.7 |
| /pricing | 21 | 133.9 | 7 | 6.1 |
| /privacy | 23.6 | 133.9 | 7 | 4.1 |
| /refunds | 15.8 | 133.9 | 7 | 6.5 |
| /security | 19.5 | 133.9 | 7 | 3.6 |
| /terms | 30 | 133.9 | 7 | 4.5 |
| /thank-you | 12 | 133.9 | 7 | 3.9 |

Asset totals conservatively include every font declared by the stylesheets and below-the-fold images, plus backgrounds declared for other pages; browsers request only the font faces actually used and defer lazy images. Measurements use the local preview without compression and do not represent mobile network speed, rendering time, Lighthouse, or production Core Web Vitals. Run Lighthouse/PageSpeed against the deployed domain for those measurements.
